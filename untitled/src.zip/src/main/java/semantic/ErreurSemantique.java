package main.java.semantic;

public class ErreurSemantique extends RuntimeException {
    public ErreurSemantique(String message) {
        super(message);
    }
}
