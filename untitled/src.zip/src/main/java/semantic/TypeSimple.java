package main.java.semantic;

public enum TypeSimple {
    ENTIER,
    BOOLEEN,
    TEXTE,
    CARACTERE,
    VIDE,
    INCONNU
}

