package main.java.parseur.ast;

import main.java.semantic.AnalyseSemantique;
import utils.diag.Position;

import java.util.List;

public class Bloc extends Instruction{
    private final List<Instruction> instructions;

    public Bloc(Position pos,List<Instruction> instructions) {
        super(pos);
        this.instructions = instructions;
    }
    public List<Instruction> getInstructions() {
        return instructions;
    }
    @Override
    public String genJava(AnalyseSemantique sem) {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        for (Instruction instr : instructions) {
            sb.append("  ").append(instr.genJava(sem)).append("\n"); // ✅ sem
        }
        sb.append("}");
        return sb.toString();
    }

}
