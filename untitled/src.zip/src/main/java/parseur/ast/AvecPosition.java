package main.java.parseur.ast;

// package main.java.parseur.ast;


import utils.diag.Position;

public interface AvecPosition {
    Position getPosition(); // peut être null au début
}
