package main.java.parseur.ast;

import main.java.semantic.AnalyseSemantique;
import utils.diag.Position;

public class ExpressionInstr extends Instruction {
    private final Expression expression;

    public ExpressionInstr(Position pos, Expression expression) {
        super(pos);
        this.expression = expression;
    }

    public Expression getExpression() { return expression; }

    @Override
    public String genJava(AnalyseSemantique sem) {
        return expression.genJava(sem) + ";";
    }
}
